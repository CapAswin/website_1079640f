<?php

declare(strict_types=1);

if (!isset($pdo)) {
    $init = is_file(dirname(__DIR__, 2) . '/_init.php') ? dirname(__DIR__, 2) . '/_init.php' : dirname(__DIR__, 3) . '/_init.php';
    list($pdo, $config) = require $init;
}
$influencerId = (int) ($_POST['influencer_id'] ?? 0);
if ($influencerId < 1) {
    json_fail('influencer_id required', [], 400);
}

$stmt = $pdo->prepare('SELECT 1 FROM influencer WHERE influencer_id = ?');
$stmt->execute([$influencerId]);
if (!$stmt->fetch()) {
    json_fail('Influencer not found', [], 404);
}

$openToCollab = (int) ($_POST['open_to_brand_collab'] ?? 1);
$pricePerPost = isset($_POST['price_per_post']) ? (float) $_POST['price_per_post'] : null;
$isNegotiable = (int) ($_POST['is_negotiable'] ?? 1);
$collabType = in_array($_POST['collaboration_type'] ?? '', ['paid', 'affiliate', 'barter'], true) ? $_POST['collaboration_type'] : 'paid';
$documentType = isset($_POST['document_type']) ? trim((string) $_POST['document_type']) : null;

$socialAccounts = is_array($decoded = json_decode((string) ($_POST['social_accounts'] ?? '[]'), true)) ? $decoded : [];

$errors = [];
if ($pricePerPost !== null && ($pricePerPost < 0 || $pricePerPost > 999999.99)) {
    $errors['price_per_post'] = 'Invalid';
}

$root = dirname(__DIR__, 2);
if (!is_file($root . '/config/config.php')) {
    $root = dirname(__DIR__, 3);
}
$uploadDir = $root . '/uploads/influencer_documents/';
$documentPath = null;
if (!empty($_FILES['document_file']['name']) && $_FILES['document_file']['error'] === UPLOAD_ERR_OK) {
    $ext = strtolower(pathinfo($_FILES['document_file']['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'pdf'];
    $maxSize = 5242880;
    if (!in_array($ext, $allowed, true)) {
        $errors['document_file'] = 'Allowed: jpg, jpeg, png, pdf';
    } elseif ($_FILES['document_file']['size'] > $maxSize) {
        $errors['document_file'] = 'Max 5MB';
    } else {
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $name = 'influencer_' . $influencerId . '_doc_' . time() . '.' . $ext;
        if (move_uploaded_file($_FILES['document_file']['tmp_name'], $uploadDir . $name)) {
            $documentPath = 'uploads/influencer_documents/' . $name;
        } else {
            $errors['document_file'] = 'Upload failed';
        }
    }
}
if ($errors !== []) {
    json_fail('Validation failed', $errors, 422);
}

$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare('SELECT pricing_id FROM content_pricing WHERE influencer_id = ?');
    $stmt->execute([$influencerId]);
    $exists = $stmt->fetch();

    if ($exists) {
        $pdo->prepare(
            'UPDATE content_pricing SET collaboration_type = ?, open_to_brand_collab = ?, price_per_post = ?, is_negotiable = ?, currency = ? WHERE influencer_id = ?'
        )->execute([$collabType, $openToCollab, $pricePerPost, $isNegotiable, 'USD', $influencerId]);
    } else {
        $pdo->prepare(
            'INSERT INTO content_pricing (influencer_id, collaboration_type, open_to_brand_collab, price_per_post, is_negotiable, currency) VALUES (?, ?, ?, ?, ?, ?)'
        )->execute([$influencerId, $collabType, $openToCollab, $pricePerPost, $isNegotiable, 'USD']);
    }

    $pdo->prepare('DELETE FROM influencer_social_account WHERE influencer_id = ?')->execute([$influencerId]);
    $ins = $pdo->prepare('INSERT INTO influencer_social_account (influencer_id, platform_id, username, profile_link) VALUES (?, ?, ?, ?)');
    foreach ($socialAccounts as $a) {
        $pid = (int) ($a['platform_id'] ?? 0);
        $un = trim((string) ($a['username'] ?? ''));
        $pl = trim((string) ($a['profile_link'] ?? ''));
        if ($pid > 0 && $un !== '' && $pl !== '') {
            $ins->execute([$influencerId, $pid, $un, $pl]);
        }
    }
    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    json_server_error($config['debug'], $e->getMessage());
}

json_ok('Registration completed successfully', [
    'influencer_id'       => $influencerId,
    'verification_status' => 'pending',
    'redirect_url'        => '/dashboard',
], 201);
